import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

class Produto {
    String codigo;
    String nome;
    double valor;
    int quantidade;

    public Produto(String codigo, String nome, double valor, int quantidade) {
        this.codigo = codigo;
        this.nome = nome;
        this.valor = valor;
        this.quantidade = quantidade;
    }
}

public class SistemaEstoque {
    private static Map<String, Produto> produtos = new HashMap<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        cadastrarProdutos();

        while (true) {
            System.out.println("\n=== Sistema de Controle de Estoque ===");
            System.out.println("1. Listar produtos");
            System.out.println("2. Vender produto");
            System.out.println("3. Sair");
            System.out.print("Escolha uma opção: ");
            String opcao = scanner.nextLine();

            switch (opcao) {
                case "1":
                    listarProdutos();
                    break;
                case "2":
                    venderProduto(scanner);
                    break;
                case "3":
                    scanner.close();
                    return;
                default:
                    System.out.println("Opção inválida!");
            }
        }
    }

    private static void cadastrarProdutos() {
        produtos.put("001", new Produto("001", "Camiseta", 49.90, 10));
        produtos.put("002", new Produto("002", "Calça", 89.90, 5));
    }

    private static void listarProdutos() {
        for (Produto produto : produtos.values()) {
            System.out.printf("Código: %s, Nome: %s, Valor: R$%.2f, Estoque: %d%n",
                    produto.codigo, produto.nome, produto.valor, produto.quantidade);
        }
    }

    private static void venderProduto(Scanner scanner) {
        System.out.print("Informe o código do produto: ");
        String codigo = scanner.nextLine();
        Produto produto = produtos.get(codigo);

        if (produto == null) {
            System.out.println("Produto não encontrado!");
            return;
        }

        System.out.print("Informe a quantidade a ser vendida: ");
        int quantidade = Integer.parseInt(scanner.nextLine());

        if (produto.quantidade < quantidade) {
            System.out.println("Estoque insuficiente!");
            return;
        }

        produto.quantidade -= quantidade;
        double valorFinal = produto.valor * quantidade;

        System.out.print("Informe a forma de pagamento (Espécie ou Crédito): ");
        String formaPagamento = scanner.nextLine();
        if (formaPagamento.equalsIgnoreCase("Espécie")) {
            valorFinal *= 0.95; // 5% de desconto
        }

        System.out.printf("Total: R$%.2f%n", valorFinal);
        if (formaPagamento.equalsIgnoreCase("Espécie")) {
            System.out.print("Informe o valor pago: R$");
            double valorPago = Double.parseDouble(scanner.nextLine());
            if (valorPago > valorFinal) {
                System.out.printf("Troco: R$%.2f%n", valorPago - valorFinal);
            } else {
                System.out.println("Valor insuficiente!");
            }
        }
    }
}

