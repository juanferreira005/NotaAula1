import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

class Produto {
    String codigo;
    String nome;
    double valor;
    int quantidade;

    public Produto(String codigo, String nome, double valor, int quantidade) {
        this.codigo = codigo;
        this.nome = nome;
        this.valor = valor;
        this.quantidade = quantidade;
    }
}

